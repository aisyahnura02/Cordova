<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id15157825_akadmk","f%[10AD%+B#(w+-x","id15157825_akademik2") or die ("could not connect database");
?>